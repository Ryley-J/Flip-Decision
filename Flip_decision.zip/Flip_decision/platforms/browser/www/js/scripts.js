var app = new Framework7({
    root: "#app", /* this is the app element in html */
    routes:[
        {
            path:'/page2/',
            url:'pages/page2.html',
        }
    ]
});

var $$ = Dom7;
var mainView = app.views.create('.view-main');
var options = ['Option 1 ','Option 2 '];

$$(document).on('page:init', '.page[data-name="page2"]', function(){
    
    
    $("#choose").on("click",function(){
       $("#option-selection").hide();
       $("#option-pick").show();
        var rand = Math.floor(Math.random() * options.length); 
        console.log(rand);
        $("#option-pick").append(options[rand]);
    });
    
    $("#reset-dec").on("click",function(){
        $("#option-pick").hide();
        $("#option-selection").show();
        $("#option-pick").empty();
    });
});